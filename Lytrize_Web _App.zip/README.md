# Lytrize — Intelligent Data Analysis Platform

> ⚡ Fast, offline analytics for real-world datasets — no cloud, no complexity
>
> ## Demo Screenshots
>
> Demo screenshots are maintained in the project Wiki.

![Welcome_Screen](demo_pics/login_page.png)

![Profile_Dashboad](demo_pics/profile_page.png)
 <!--
![Upload & Overview](demo_pics/data_upload&overview.png)

![Data_Transformation](demo_pics/data_transformation.png)

![Analysis_Options](demo_pics/analysis_options.png)
-->
![Python](https://img.shields.io/badge/Python-3.9%2B-blue?logo=python)
![Streamlit](https://img.shields.io/badge/Streamlit-1.30%2B-red?logo=streamlit)
![License](https://img.shields.io/badge/License-MIT-green)
![PRs Welcome](https://img.shields.io/badge/PRs-Welcome-brightgreen)

---

<b>Lytrize is an open-source, lightweight, offline-first data analysis tool designed for individual analysts.</b><br><br>Upload a CSV or Excel file, explore it through interactive charts and generate shareable dashboards - all locally, without complex setup or cloud dependency. Check demo_pics for UI images.


## Quick Start

Please check - [Getting Started](https://github.com/VidalNat/dataLyze-oensource-data_analysis-platform/wiki/Getting-started)

## Documentation

Everything else lives in the **[project Wiki](../../wiki)**:

| Page | What's in it |
|---|---|
| [Home](https://github.com/VidalNat/dataLyze-oensource-data_analysis-platform/wiki) | Project overview & feature list |
| [Getting Started](https://github.com/VidalNat/dataLyze-oensource-data_analysis-platform/wiki/Getting-started) | Install, run, first use walkthrough |
| [Configuration](https://github.com/VidalNat/dataLyze-oensource-data_analysis-platform/wiki/Configuration) | PostgreSQL, environment variables |
| [Contributing Guide](https://github.com/VidalNat/dataLyze-oensource-data_analysis-platform/wiki/Contributing-guide) | Workflow, PR checklist, conventions |
| [Roadmap](https://github.com/VidalNat/dataLyze-oensource-data_analysis-platform/wiki/Roadmap) | Planned features & ideas |

## License

MIT — free to use, modify, and distribute.
